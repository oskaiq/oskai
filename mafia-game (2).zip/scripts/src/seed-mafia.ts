import { db, gamesTable, gamePlayersTable } from "@workspace/db";

async function seed() {
  const existing = await db.select().from(gamesTable).limit(1);
  if (existing.length > 0) {
    console.log("Already seeded");
    process.exit(0);
  }

  const seedGames = [
    {
      roomName: "ليلة الجمعة",
      winner: "town",
      playerCount: 8,
      durationSeconds: 642,
      players: [
        { name: "ياسر", role: "detective", win: true },
        { name: "ريم", role: "doctor", win: true },
        { name: "خالد", role: "citizen", win: true },
        { name: "نورة", role: "mafia", win: false },
        { name: "سلمان", role: "mafia", win: false },
        { name: "هند", role: "citizen", win: true },
        { name: "ماجد", role: "citizen", win: true },
        { name: "ليان", role: "citizen", win: true },
      ],
    },
    {
      roomName: "مقهى الزاوية",
      winner: "mafia",
      playerCount: 7,
      durationSeconds: 489,
      players: [
        { name: "ياسر", role: "citizen", win: false },
        { name: "ريم", role: "mafia", win: true },
        { name: "نورة", role: "doctor", win: false },
        { name: "ماجد", role: "mafia", win: true },
        { name: "خالد", role: "detective", win: false },
        { name: "هند", role: "citizen", win: false },
        { name: "بدر", role: "citizen", win: false },
      ],
    },
    {
      roomName: "غرفة الديوان",
      winner: "town",
      playerCount: 6,
      durationSeconds: 712,
      players: [
        { name: "ياسر", role: "doctor", win: true },
        { name: "بدر", role: "mafia", win: false },
        { name: "خالد", role: "detective", win: true },
        { name: "ليان", role: "citizen", win: true },
        { name: "هند", role: "citizen", win: true },
        { name: "ماجد", role: "citizen", win: true },
      ],
    },
  ];

  for (const g of seedGames) {
    const [game] = await db
      .insert(gamesTable)
      .values({
        roomName: g.roomName,
        winner: g.winner,
        playerCount: g.playerCount,
        durationSeconds: g.durationSeconds,
      })
      .returning();
    if (!game) continue;
    await db.insert(gamePlayersTable).values(
      g.players.map((p) => ({
        gameId: game.id,
        playerName: p.name,
        role: p.role,
        isWinner: p.win,
      })),
    );
  }
  console.log(`Seeded ${seedGames.length} games`);
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
