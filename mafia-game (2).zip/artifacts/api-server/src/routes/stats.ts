import { Router, type IRouter } from "express";
import { sql, eq, desc } from "drizzle-orm";
import { db, gamesTable, gamePlayersTable } from "@workspace/db";
import {
  GetLeaderboardResponse,
  GetRecentGamesResponse,
  GetRoleWinratesResponse,
  GetStatsOverviewResponse,
} from "@workspace/api-zod";
import { getActiveRoomCount, getOnlinePlayerCount } from "../lib/game";

const router: IRouter = Router();

router.get("/stats/overview", async (_req, res) => {
  const [{ totalGames }] = await db
    .select({ totalGames: sql<number>`cast(count(*) as int)` })
    .from(gamesTable);
  const [{ gamesToday }] = await db
    .select({
      gamesToday: sql<number>`cast(count(*) as int)`,
    })
    .from(gamesTable)
    .where(sql`${gamesTable.endedAt} > now() - interval '24 hours'`);

  res.json(
    GetStatsOverviewResponse.parse({
      activeRooms: getActiveRoomCount(),
      playersOnline: getOnlinePlayerCount(),
      gamesToday: gamesToday ?? 0,
      totalGames: totalGames ?? 0,
    }),
  );
});

router.get("/stats/leaderboard", async (_req, res) => {
  const rows = await db
    .select({
      playerName: gamePlayersTable.playerName,
      wins: sql<number>`cast(sum(case when ${gamePlayersTable.isWinner} then 1 else 0 end) as int)`,
      losses: sql<number>`cast(sum(case when ${gamePlayersTable.isWinner} then 0 else 1 end) as int)`,
      gamesPlayed: sql<number>`cast(count(*) as int)`,
    })
    .from(gamePlayersTable)
    .groupBy(gamePlayersTable.playerName)
    .orderBy(
      desc(
        sql`sum(case when ${gamePlayersTable.isWinner} then 1 else 0 end)`,
      ),
    )
    .limit(10);

  const out = rows.map((r) => ({
    playerName: r.playerName,
    wins: Number(r.wins ?? 0),
    losses: Number(r.losses ?? 0),
    gamesPlayed: Number(r.gamesPlayed ?? 0),
    winRate:
      r.gamesPlayed && Number(r.gamesPlayed) > 0
        ? Number(r.wins) / Number(r.gamesPlayed)
        : 0,
  }));
  res.json(GetLeaderboardResponse.parse(out));
});

router.get("/stats/recent-games", async (_req, res) => {
  const rows = await db
    .select()
    .from(gamesTable)
    .orderBy(desc(gamesTable.endedAt))
    .limit(10);
  const out = rows.map((g) => ({
    id: g.id,
    roomName: g.roomName,
    winner: g.winner as "mafia" | "town",
    playerCount: g.playerCount,
    durationSeconds: g.durationSeconds,
    endedAt: g.endedAt.toISOString(),
  }));
  res.json(GetRecentGamesResponse.parse(out));
});

router.get("/stats/role-winrates", async (_req, res) => {
  const rows = await db
    .select({
      role: gamePlayersTable.role,
      wins: sql<number>`cast(sum(case when ${gamePlayersTable.isWinner} then 1 else 0 end) as int)`,
      gamesPlayed: sql<number>`cast(count(*) as int)`,
    })
    .from(gamePlayersTable)
    .groupBy(gamePlayersTable.role);

  const out = rows.map((r) => ({
    role: r.role,
    gamesPlayed: Number(r.gamesPlayed ?? 0),
    winRate:
      r.gamesPlayed && Number(r.gamesPlayed) > 0
        ? Number(r.wins) / Number(r.gamesPlayed)
        : 0,
  }));
  res.json(GetRoleWinratesResponse.parse(out));
});

export default router;
// silence unused import warning
void eq;
