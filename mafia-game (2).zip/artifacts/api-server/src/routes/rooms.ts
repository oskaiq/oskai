import { Router, type IRouter } from "express";
import {
  CreateRoomBody,
  GetRoomParams,
  GetRoomResponse,
  ListRoomsResponse,
} from "@workspace/api-zod";
import {
  createRoom,
  fullRoomData,
  getRoom,
  listPublicRooms,
  publicSummary,
} from "../lib/game";

const router: IRouter = Router();

router.get("/rooms", (_req, res) => {
  const rooms = listPublicRooms()
    .sort((a, b) => b.createdAt - a.createdAt)
    .map(publicSummary);
  res.json(ListRoomsResponse.parse(rooms));
});

router.post("/rooms", (req, res) => {
  const parsed = CreateRoomBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const room = createRoom({
    name: parsed.data.name,
    hostName: parsed.data.hostName,
    maxPlayers: parsed.data.maxPlayers,
    isPrivate: parsed.data.isPrivate ?? false,
  });
  res.status(201).json(GetRoomResponse.parse(fullRoomData(room)));
});

router.get("/rooms/:code", (req, res) => {
  const params = GetRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const room = getRoom(params.data.code);
  if (!room) {
    res.status(404).json({ error: "Room not found" });
    return;
  }
  res.json(GetRoomResponse.parse(fullRoomData(room)));
});

export default router;
