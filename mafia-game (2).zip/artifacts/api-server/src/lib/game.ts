import { randomUUID } from "node:crypto";
import { db, gamesTable, gamePlayersTable } from "@workspace/db";
import { logger } from "./logger";

export type Phase = "lobby" | "night" | "day" | "ended";
export type Role = "mafia" | "doctor" | "detective" | "citizen";
export type ChatChannel = "public" | "mafia" | "system";
export type Winner = "mafia" | "town";

export interface ChatMessage {
  id: string;
  from: string;
  text: string;
  channel: ChatChannel;
  timestamp: number;
}

export interface Player {
  id: string;
  name: string;
  isHost: boolean;
  isAlive: boolean;
  role?: Role;
  connected: boolean;
  ready: boolean;
}

export interface NightActions {
  mafiaTargets: Map<string, string>;
  doctorTarget?: string;
  detectiveTarget?: string;
}

export interface Room {
  code: string;
  name: string;
  hostName: string;
  maxPlayers: number;
  isPrivate: boolean;
  phase: Phase;
  createdAt: number;
  startedAt?: number;
  players: Map<string, Player>;
  chat: ChatMessage[];
  votes: Map<string, string>;
  nightActions: NightActions;
  phaseEndsAt: number;
  winner?: Winner;
  detectiveResult?: { targetId: string; isMafia: boolean };
  killedThisNight?: string;
  savedThisNight?: boolean;
  ejectedThisDay?: string;
}

const PHASE_DURATIONS = {
  lobby: 0,
  night: 30_000,
  day: 60_000,
  ended: 0,
} as const;

const rooms = new Map<string, Room>();
const playerRoomIndex = new Map<string, string>();

function makeCode(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let attempts = 0;
  while (attempts < 50) {
    let code = "";
    for (let i = 0; i < 5; i++) {
      code += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    if (!rooms.has(code)) return code;
    attempts += 1;
  }
  return randomUUID().slice(0, 6).toUpperCase();
}

function emptyNightActions(): NightActions {
  return {
    mafiaTargets: new Map(),
  };
}

export function createRoom(input: {
  name: string;
  hostName: string;
  maxPlayers: number;
  isPrivate: boolean;
}): Room {
  const code = makeCode();
  const room: Room = {
    code,
    name: input.name,
    hostName: input.hostName,
    maxPlayers: input.maxPlayers,
    isPrivate: input.isPrivate,
    phase: "lobby",
    createdAt: Date.now(),
    players: new Map(),
    chat: [],
    votes: new Map(),
    nightActions: emptyNightActions(),
    phaseEndsAt: 0,
  };
  rooms.set(code, room);
  logger.info({ code, name: room.name }, "Room created");
  return room;
}

export function getRoom(code: string): Room | undefined {
  return rooms.get(code.toUpperCase());
}

export function listPublicRooms(): Room[] {
  return [...rooms.values()].filter(
    (r) => !r.isPrivate && r.phase !== "ended",
  );
}

export function getActiveRoomCount(): number {
  return [...rooms.values()].filter((r) => r.phase !== "ended").length;
}

export function getOnlinePlayerCount(): number {
  let count = 0;
  for (const r of rooms.values()) {
    if (r.phase === "ended") continue;
    for (const p of r.players.values()) if (p.connected) count += 1;
  }
  return count;
}

export function findPlayerRoom(playerId: string): Room | undefined {
  const code = playerRoomIndex.get(playerId);
  if (!code) return undefined;
  return rooms.get(code);
}

export function joinRoom(
  room: Room,
  playerName: string,
  preferredId?: string,
): Player | { error: string } {
  if (room.phase === "ended") {
    return { error: "هذه الغرفة منتهية" };
  }

  const trimmed = playerName.trim().slice(0, 20);
  if (trimmed.length < 2) return { error: "الاسم قصير جدًا" };

  // Reconnect by id.
  if (preferredId && room.players.has(preferredId)) {
    const existing = room.players.get(preferredId)!;
    existing.connected = true;
    playerRoomIndex.set(existing.id, room.code);
    return existing;
  }

  // Reconnect by name (helps survive page refresh without saved id).
  for (const p of room.players.values()) {
    if (p.name === trimmed) {
      p.connected = true;
      playerRoomIndex.set(p.id, room.code);
      return p;
    }
  }

  if (room.phase !== "lobby") {
    return { error: "لا يمكن الانضمام، اللعبة بدأت" };
  }
  if (room.players.size >= room.maxPlayers) {
    return { error: "الغرفة ممتلئة" };
  }

  const id = preferredId ?? randomUUID();
  const isHost = room.players.size === 0;
  const player: Player = {
    id,
    name: trimmed,
    isHost,
    isAlive: true,
    connected: true,
    ready: false,
  };
  if (isHost) room.hostName = trimmed;
  room.players.set(id, player);
  playerRoomIndex.set(id, room.code);
  pushChat(room, "النظام", `انضم ${trimmed} إلى الغرفة`, "system");
  return player;
}

export function disconnectPlayer(room: Room, playerId: string): void {
  const player = room.players.get(playerId);
  if (!player) return;
  player.connected = false;
  if (room.phase === "lobby") {
    room.players.delete(playerId);
    playerRoomIndex.delete(playerId);
    pushChat(room, "النظام", `غادر ${player.name} الغرفة`, "system");
    if (player.isHost) {
      const next = [...room.players.values()][0];
      if (next) {
        next.isHost = true;
        room.hostName = next.name;
      }
    }
  }
}

function pushChat(
  room: Room,
  from: string,
  text: string,
  channel: ChatChannel,
): ChatMessage {
  const msg: ChatMessage = {
    id: randomUUID(),
    from,
    text,
    channel,
    timestamp: Date.now(),
  };
  room.chat.push(msg);
  if (room.chat.length > 200) room.chat.splice(0, room.chat.length - 200);
  return msg;
}

export function sendChat(
  room: Room,
  player: Player,
  text: string,
  channel: ChatChannel,
): ChatMessage | { error: string } {
  const trimmed = text.trim().slice(0, 280);
  if (!trimmed) return { error: "الرسالة فارغة" };
  if (channel === "system") return { error: "ممنوع" };

  if (channel === "mafia") {
    if (player.role !== "mafia" || room.phase !== "night") {
      return { error: "هذه القناة مغلقة" };
    }
  } else {
    if (room.phase === "night" && player.isAlive) {
      return { error: "ممنوع التحدث في الليل" };
    }
    if (!player.isAlive && room.phase !== "ended") {
      return { error: "الموتى لا يتحدثون" };
    }
  }

  return pushChat(room, player.name, trimmed, channel);
}

export function startGame(
  room: Room,
  playerId: string,
): { ok: true } | { error: string } {
  const player = room.players.get(playerId);
  if (!player?.isHost) return { error: "فقط المضيف يبدأ اللعبة" };
  if (room.phase !== "lobby") return { error: "اللعبة بدأت بالفعل" };
  if (room.players.size < 5) return { error: "تحتاج خمسة لاعبين على الأقل" };

  assignRoles(room);
  room.startedAt = Date.now();
  enterNight(room);
  return { ok: true };
}

function assignRoles(room: Room): void {
  const ids = [...room.players.keys()];
  shuffle(ids);
  const total = ids.length;
  const mafiaCount = total <= 6 ? 1 : total <= 9 ? 2 : 3;
  const roles: Role[] = [];
  for (let i = 0; i < mafiaCount; i++) roles.push("mafia");
  roles.push("doctor");
  roles.push("detective");
  while (roles.length < total) roles.push("citizen");
  shuffle(roles);
  ids.forEach((id, idx) => {
    const player = room.players.get(id)!;
    player.role = roles[idx]!;
  });
  pushChat(
    room,
    "النظام",
    `بدأت اللعبة! ${total} لاعبون، ${mafiaCount} من المافيا.`,
    "system",
  );
}

function shuffle<T>(arr: T[]): void {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j]!, arr[i]!];
  }
}

function enterNight(room: Room): void {
  room.phase = "night";
  room.phaseEndsAt = Date.now() + PHASE_DURATIONS.night;
  room.nightActions = emptyNightActions();
  room.detectiveResult = undefined;
  room.killedThisNight = undefined;
  room.savedThisNight = undefined;
  room.ejectedThisDay = undefined;
  for (const p of room.players.values()) p.ready = false;
  pushChat(
    room,
    "النظام",
    "حلّ الليل، أغمضت المدينة عيونها...",
    "system",
  );
}

function enterDay(room: Room): void {
  resolveNight(room);
  room.phase = "day";
  room.phaseEndsAt = Date.now() + PHASE_DURATIONS.day;
  room.votes = new Map();
  for (const p of room.players.values()) p.ready = false;
  if (checkWin(room)) return;
  pushChat(
    room,
    "النظام",
    "أشرقت الشمس، حان وقت النقاش والتصويت.",
    "system",
  );
}

function resolveNight(room: Room): void {
  const tally = new Map<string, number>();
  for (const target of room.nightActions.mafiaTargets.values()) {
    tally.set(target, (tally.get(target) ?? 0) + 1);
  }
  let killed: string | undefined;
  let max = 0;
  for (const [target, count] of tally) {
    if (count > max) {
      killed = target;
      max = count;
    }
  }

  if (killed) {
    if (room.nightActions.doctorTarget === killed) {
      room.savedThisNight = true;
      pushChat(
        room,
        "النظام",
        "حاولت المافيا القتل الليلة، لكن أنقذ الطبيب الضحية!",
        "system",
      );
    } else {
      const victim = room.players.get(killed);
      if (victim) {
        victim.isAlive = false;
        room.killedThisNight = killed;
        pushChat(
          room,
          "النظام",
          `استيقظت المدينة على خبر مقتل ${victim.name}.`,
          "system",
        );
      }
    }
  } else {
    pushChat(room, "النظام", "ليلة هادئة... لم يُقتل أحد.", "system");
  }
}

function endDay(room: Room): void {
  let topId: string | undefined;
  let topCount = 0;
  let tied = false;
  const tally = new Map<string, number>();
  for (const target of room.votes.values()) {
    tally.set(target, (tally.get(target) ?? 0) + 1);
  }
  for (const [target, count] of tally) {
    if (count > topCount) {
      topId = target;
      topCount = count;
      tied = false;
    } else if (count === topCount) {
      tied = true;
    }
  }

  if (topId && !tied) {
    const ejected = room.players.get(topId);
    if (ejected) {
      ejected.isAlive = false;
      room.ejectedThisDay = topId;
      const roleLabel = arabicRole(ejected.role);
      pushChat(
        room,
        "النظام",
        `أقصى المجلسُ ${ejected.name}، وكان دوره: ${roleLabel}.`,
        "system",
      );
    }
  } else {
    pushChat(room, "النظام", "لم يُتفق على اقصاء أحد اليوم.", "system");
  }

  if (checkWin(room)) return;
  enterNight(room);
}

function checkWin(room: Room): boolean {
  const alive = [...room.players.values()].filter((p) => p.isAlive);
  const aliveMafia = alive.filter((p) => p.role === "mafia").length;
  const aliveTown = alive.length - aliveMafia;

  if (aliveMafia === 0) {
    endGame(room, "town");
    return true;
  }
  if (aliveMafia >= aliveTown) {
    endGame(room, "mafia");
    return true;
  }
  return false;
}

function endGame(room: Room, winner: Winner): void {
  room.phase = "ended";
  room.winner = winner;
  room.phaseEndsAt = Date.now() + 60_000;
  pushChat(
    room,
    "النظام",
    winner === "mafia"
      ? "انتصرت المافيا! المدينة سقطت."
      : "انتصرت المدينة! المافيا أُقصيت.",
    "system",
  );
  void persistGame(room);
}

async function persistGame(room: Room): Promise<void> {
  if (!room.startedAt || !room.winner) return;
  try {
    const duration = Math.floor((Date.now() - room.startedAt) / 1000);
    const players = [...room.players.values()];
    const [game] = await db
      .insert(gamesTable)
      .values({
        roomName: room.name,
        winner: room.winner,
        playerCount: players.length,
        durationSeconds: duration,
      })
      .returning();
    if (!game) return;
    const winner = room.winner;
    await db.insert(gamePlayersTable).values(
      players.map((p) => ({
        gameId: game.id,
        playerName: p.name,
        role: p.role ?? "citizen",
        isWinner:
          (winner === "mafia" && p.role === "mafia") ||
          (winner === "town" && p.role !== "mafia"),
      })),
    );
  } catch (err) {
    logger.error({ err }, "Failed to persist game");
  }
}

export function castVote(
  room: Room,
  voter: Player,
  targetId: string,
): { ok: true } | { error: string } {
  if (room.phase !== "day") return { error: "ليس وقت التصويت" };
  if (!voter.isAlive) return { error: "الموتى لا يصوتون" };
  const target = room.players.get(targetId);
  if (!target?.isAlive) return { error: "هدف غير صالح" };
  room.votes.set(voter.id, targetId);
  pushChat(room, "النظام", `صوّت ${voter.name} ضد ${target.name}.`, "system");
  return { ok: true };
}

export function nightAction(
  room: Room,
  actor: Player,
  targetId: string,
): { ok: true } | { error: string } {
  if (room.phase !== "night") return { error: "ليس وقت الفعل" };
  if (!actor.isAlive) return { error: "الموتى لا يتحركون" };
  const target = room.players.get(targetId);
  if (!target?.isAlive) return { error: "هدف غير صالح" };

  switch (actor.role) {
    case "mafia":
      if (target.role === "mafia") return { error: "لا تستهدف زميلك" };
      room.nightActions.mafiaTargets.set(actor.id, targetId);
      return { ok: true };
    case "doctor":
      room.nightActions.doctorTarget = targetId;
      return { ok: true };
    case "detective":
      room.nightActions.detectiveTarget = targetId;
      room.detectiveResult = {
        targetId,
        isMafia: target.role === "mafia",
      };
      return { ok: true };
    default:
      return { error: "لا يملك دورك فعلًا في الليل" };
  }
}

export function setReady(room: Room, player: Player): void {
  player.ready = true;
}

export function tickRoom(room: Room): boolean {
  if (room.phase === "lobby") return false;
  if (room.phase === "ended") {
    if (Date.now() > room.phaseEndsAt + 5 * 60_000) {
      rooms.delete(room.code);
      for (const p of room.players.values()) playerRoomIndex.delete(p.id);
      return true;
    }
    return false;
  }

  const livingActors = [...room.players.values()].filter(
    (p) => p.isAlive && needsAction(room, p),
  );
  const allReady =
    livingActors.length > 0 && livingActors.every((p) => p.ready);

  if (Date.now() >= room.phaseEndsAt || allReady) {
    if (room.phase === "night") enterDay(room);
    else if (room.phase === "day") endDay(room);
    return true;
  }
  return false;
}

function needsAction(room: Room, player: Player): boolean {
  if (room.phase === "night") {
    return (
      player.role === "mafia" ||
      player.role === "doctor" ||
      player.role === "detective"
    );
  }
  if (room.phase === "day") return true;
  return false;
}

export function arabicRole(role?: Role): string {
  switch (role) {
    case "mafia":
      return "المافيا";
    case "doctor":
      return "الطبيب";
    case "detective":
      return "المحقق";
    case "citizen":
      return "مواطن";
    default:
      return "غير معروف";
  }
}

export function snapshotForPlayer(room: Room, viewerId: string) {
  const viewer = room.players.get(viewerId);
  const showAllRoles = room.phase === "ended";
  const players = [...room.players.values()].map((p) => ({
    id: p.id,
    name: p.name,
    isHost: p.isHost,
    isAlive: p.isAlive,
    connected: p.connected,
    ready: p.ready,
    role:
      showAllRoles ||
      p.id === viewerId ||
      (viewer?.role === "mafia" && p.role === "mafia")
        ? p.role
        : undefined,
  }));

  const visibleChat = room.chat.filter((m) => {
    if (m.channel === "public" || m.channel === "system") return true;
    if (m.channel === "mafia") {
      return viewer?.role === "mafia" || showAllRoles;
    }
    return false;
  });

  const votes = [...room.votes.entries()].map(([voterId, targetId]) => ({
    voterId,
    targetId,
  }));

  return {
    code: room.code,
    name: room.name,
    hostName: room.hostName,
    maxPlayers: room.maxPlayers,
    isPrivate: room.isPrivate,
    phase: room.phase,
    createdAt: new Date(room.createdAt).toISOString(),
    startedAt: room.startedAt
      ? new Date(room.startedAt).toISOString()
      : undefined,
    phaseEndsAt: room.phaseEndsAt,
    timeRemaining: Math.max(0, room.phaseEndsAt - Date.now()),
    winner: room.winner,
    players,
    chat: visibleChat,
    votes,
    you: viewer
      ? {
          id: viewer.id,
          name: viewer.name,
          role: viewer.role,
          isAlive: viewer.isAlive,
          isHost: viewer.isHost,
          ready: viewer.ready,
          detectiveResult:
            viewer.role === "detective" ? room.detectiveResult : undefined,
        }
      : null,
  };
}

export function publicSummary(room: Room) {
  return {
    code: room.code,
    name: room.name,
    hostName: room.hostName,
    playerCount: room.players.size,
    maxPlayers: room.maxPlayers,
    phase: room.phase,
    createdAt: new Date(room.createdAt).toISOString(),
  };
}

export function fullRoomData(room: Room) {
  return {
    code: room.code,
    name: room.name,
    hostName: room.hostName,
    maxPlayers: room.maxPlayers,
    isPrivate: room.isPrivate,
    phase: room.phase,
    createdAt: new Date(room.createdAt).toISOString(),
    players: [...room.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      isHost: p.isHost,
      isAlive: p.isAlive,
    })),
  };
}
