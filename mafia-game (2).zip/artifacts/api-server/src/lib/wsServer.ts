import type { Server as HttpServer, IncomingMessage } from "node:http";
import { WebSocketServer, WebSocket } from "ws";
import {
  castVote,
  disconnectPlayer,
  getRoom,
  joinRoom,
  nightAction,
  sendChat,
  setReady,
  snapshotForPlayer,
  startGame,
  tickRoom,
  type ChatChannel,
  type Room,
} from "./game";
import { logger } from "./logger";

interface SocketState {
  roomCode: string;
  playerId: string;
  alive: boolean;
}

interface ClientMessage {
  type: string;
  text?: string;
  channel?: ChatChannel;
  targetId?: string;
}

const ROOM_CHANNELS = new Map<string, Set<WebSocket>>();
const SOCKET_STATE = new WeakMap<WebSocket, SocketState>();

function broadcastState(room: Room): void {
  const sockets = ROOM_CHANNELS.get(room.code);
  if (!sockets) return;
  for (const ws of sockets) {
    if (ws.readyState !== WebSocket.OPEN) continue;
    const state = SOCKET_STATE.get(ws);
    if (!state) continue;
    const payload = JSON.stringify({
      type: "state",
      room: snapshotForPlayer(room, state.playerId),
    });
    ws.send(payload);
  }
}

function sendError(ws: WebSocket, message: string): void {
  if (ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({ type: "error", message }));
}

function attachSocket(
  ws: WebSocket,
  room: Room,
  playerId: string,
): void {
  let bucket = ROOM_CHANNELS.get(room.code);
  if (!bucket) {
    bucket = new Set();
    ROOM_CHANNELS.set(room.code, bucket);
  }
  bucket.add(ws);
  SOCKET_STATE.set(ws, { roomCode: room.code, playerId, alive: true });
}

function detachSocket(ws: WebSocket): void {
  const state = SOCKET_STATE.get(ws);
  if (!state) return;
  const bucket = ROOM_CHANNELS.get(state.roomCode);
  if (bucket) {
    bucket.delete(ws);
    if (bucket.size === 0) ROOM_CHANNELS.delete(state.roomCode);
  }
  const room = getRoom(state.roomCode);
  if (room) {
    disconnectPlayer(room, state.playerId);
    broadcastState(room);
  }
}

export function attachWebSocketServer(server: HttpServer): void {
  const wss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (req, socket, head) => {
    const url = new URL(req.url ?? "/", `http://${req.headers.host}`);
    if (!url.pathname.endsWith("/ws")) {
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  });

  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url ?? "/", `http://${req.headers.host}`);
    const code = url.searchParams.get("code")?.toUpperCase();
    const name = url.searchParams.get("name") ?? "";
    const preferredId = url.searchParams.get("playerId") ?? undefined;
    if (!code) {
      sendError(ws, "كود الغرفة مفقود");
      ws.close();
      return;
    }
    const room = getRoom(code);
    if (!room) {
      sendError(ws, "الغرفة غير موجودة");
      ws.close();
      return;
    }

    const result = joinRoom(room, name, preferredId);
    if ("error" in result) {
      sendError(ws, result.error);
      ws.close();
      return;
    }
    attachSocket(ws, room, result.id);
    ws.send(
      JSON.stringify({
        type: "joined",
        playerId: result.id,
      }),
    );
    broadcastState(room);

    ws.on("message", (raw) => {
      let msg: ClientMessage;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return sendError(ws, "رسالة غير صالحة");
      }
      const state = SOCKET_STATE.get(ws);
      if (!state) return;
      const liveRoom = getRoom(state.roomCode);
      if (!liveRoom) return;
      const player = liveRoom.players.get(state.playerId);
      if (!player) return;

      switch (msg.type) {
        case "chat": {
          const r = sendChat(
            liveRoom,
            player,
            msg.text ?? "",
            msg.channel ?? "public",
          );
          if ("error" in r) sendError(ws, r.error);
          else broadcastState(liveRoom);
          break;
        }
        case "start": {
          const r = startGame(liveRoom, player.id);
          if ("error" in r) sendError(ws, r.error);
          else broadcastState(liveRoom);
          break;
        }
        case "vote": {
          if (!msg.targetId) return sendError(ws, "هدف مفقود");
          const r = castVote(liveRoom, player, msg.targetId);
          if ("error" in r) sendError(ws, r.error);
          else broadcastState(liveRoom);
          break;
        }
        case "action": {
          if (!msg.targetId) return sendError(ws, "هدف مفقود");
          const r = nightAction(liveRoom, player, msg.targetId);
          if ("error" in r) sendError(ws, r.error);
          else broadcastState(liveRoom);
          break;
        }
        case "ready": {
          setReady(liveRoom, player);
          broadcastState(liveRoom);
          break;
        }
        case "ping":
          break;
        default:
          sendError(ws, "أمر غير معروف");
      }
    });

    ws.on("close", () => {
      detachSocket(ws);
    });

    ws.on("error", (err) => {
      logger.warn({ err: err.message }, "WebSocket error");
    });
  });

  setInterval(() => {
    const seen = new Set<string>();
    for (const sockets of ROOM_CHANNELS.values()) {
      for (const ws of sockets) {
        const state = SOCKET_STATE.get(ws);
        if (!state) continue;
        if (seen.has(state.roomCode)) continue;
        seen.add(state.roomCode);
        const room = getRoom(state.roomCode);
        if (!room) continue;
        const changed = tickRoom(room);
        if (changed) broadcastState(room);
        else broadcastTimer(room);
      }
    }
  }, 1000);
}

function broadcastTimer(room: Room): void {
  const sockets = ROOM_CHANNELS.get(room.code);
  if (!sockets) return;
  for (const ws of sockets) {
    if (ws.readyState !== WebSocket.OPEN) continue;
    const state = SOCKET_STATE.get(ws);
    if (!state) continue;
    ws.send(
      JSON.stringify({
        type: "tick",
        timeRemaining: Math.max(0, room.phaseEndsAt - Date.now()),
        phase: room.phase,
      }),
    );
  }
}
