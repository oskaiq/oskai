import { useEffect, useRef, useState, useCallback } from 'react';

export type GamePhase = 'lobby' | 'night' | 'day' | 'ended';
export type PlayerRole = 'mafia' | 'doctor' | 'detective' | 'citizen';
export type ChatChannel = 'public' | 'mafia' | 'system';
export type Winner = 'mafia' | 'town';

export interface GamePlayer {
  id: string;
  name: string;
  isHost: boolean;
  isAlive: boolean;
  role?: PlayerRole;
}

export interface ChatMessage {
  id: string;
  from: string;
  text: string;
  channel: ChatChannel;
  timestamp: string;
}

export interface GameState {
  code: string;
  name: string;
  phase: GamePhase;
  maxPlayers: number;
  players: GamePlayer[];
  chat: ChatMessage[];
  timeRemaining: number;
  votes?: { voterId: string; targetId: string }[];
  winner?: Winner;
  you: {
    id: string;
    role?: PlayerRole;
    isAlive: boolean;
    isHost: boolean;
  } | null;
}

type ServerMessage = 
  | { type: 'state'; room: GameState }
  | { type: 'chat'; message: ChatMessage }
  | { type: 'error'; message: string };

type ClientMessage =
  | { type: 'chat'; text: string; channel: 'public' | 'mafia' }
  | { type: 'start' }
  | { type: 'vote'; targetId: string }
  | { type: 'action'; targetId: string }
  | { type: 'ready' };

export function useGameSocket(code: string, playerName: string) {
  const [state, setState] = useState<GameState | null>(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (!code || !playerName) return;

    const wsProto = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, "");
    const wsUrl = `${wsProto}://${window.location.host}${baseUrl}/ws?code=${code}&name=${encodeURIComponent(playerName)}`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      setError(null);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data) as ServerMessage;
        if (msg.type === 'state') {
          setState(msg.room);
        } else if (msg.type === 'chat') {
          setState((prev) => {
            if (!prev) return prev;
            // Prevent duplicates
            if (prev.chat.some(c => c.id === msg.message.id)) return prev;
            return {
              ...prev,
              chat: [...prev.chat, msg.message]
            };
          });
        } else if (msg.type === 'error') {
          setError(msg.message);
        }
      } catch (err) {
        console.error("Failed to parse websocket message", err);
      }
    };

    ws.onclose = () => {
      setConnected(false);
      // Reconnect logic
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 3000);
    };

    ws.onerror = () => {
      // Handled by onclose
    };
  }, [code, playerName]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  const send = useCallback((msg: ClientMessage) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  }, []);

  return { state, send, connected, error };
}
