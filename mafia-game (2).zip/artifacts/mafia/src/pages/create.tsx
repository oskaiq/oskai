import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCreateRoom } from "@workspace/api-client-react";
import { useAuth } from "@workspace/replit-auth-web";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { ArrowRight, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CreateRoom() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [playerName, setPlayerName] = useLocalStorage<string>("mafia-player-name", "");
  const { user } = useAuth();

  useEffect(() => {
    if (user && !playerName) {
      const name =
        user.firstName ||
        (user.email ? user.email.split("@")[0] : "");
      if (name) setPlayerName(name);
    }
  }, [user, playerName, setPlayerName]);

  const [roomName, setRoomName] = useState("");
  const [maxPlayers, setMaxPlayers] = useState([8]);
  const [isPrivate, setIsPrivate] = useState(false);

  const createRoom = useCreateRoom();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomName || !playerName) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم الغرفة واسم اللاعب",
        variant: "destructive"
      });
      return;
    }

    createRoom.mutate(
      {
        data: {
          name: roomName,
          hostName: playerName,
          maxPlayers: maxPlayers[0],
          isPrivate
        }
      },
      {
        onSuccess: (room) => {
          toast({
            title: "تم إنشاء الغرفة",
            description: "جاري تحويلك للغرفة..."
          });
          setLocation(`/room/${room.code}`);
        },
        onError: () => {
          toast({
            title: "حدث خطأ",
            description: "لم نتمكن من إنشاء الغرفة. حاول مرة أخرى.",
            variant: "destructive"
          });
        }
      }
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4 relative overflow-hidden">
      <div className="noise-overlay" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        <Link href="/" className="inline-flex items-center text-muted-foreground hover:text-white mb-6 transition-colors">
          <ArrowRight className="w-4 h-4 ml-2" /> عودة للرئيسية
        </Link>
        
        <Card className="bg-black/60 border-red-900/30 backdrop-blur-md shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-red-500">إنشاء غرفة جديدة</CardTitle>
            <CardDescription className="text-muted-foreground">
              قم بإنشاء غرفة ودعوة أصدقائك للعب
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form id="create-room-form" onSubmit={handleSubmit} className="space-y-6">
              
              <div className="space-y-2">
                <Label htmlFor="roomName" className="text-red-100">اسم الغرفة</Label>
                <Input 
                  id="roomName" 
                  value={roomName}
                  onChange={(e) => setRoomName(e.target.value)}
                  placeholder="مثال: جلسة منتصف الليل" 
                  className="bg-black/40 border-red-900/50 focus:border-red-500"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="playerName" className="text-red-100">اسمك (المضيف)</Label>
                <Input 
                  id="playerName" 
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="كيف تريد أن يناديك اللاعبون؟" 
                  className="bg-black/40 border-red-900/50 focus:border-red-500"
                  required
                />
              </div>

              <div className="space-y-4 pt-2">
                <div className="flex justify-between items-center">
                  <Label className="text-red-100">الحد الأقصى للاعبين</Label>
                  <span className="font-bold text-red-500 text-lg">{maxPlayers[0]} لاعبين</span>
                </div>
                <Slider
                  defaultValue={[8]}
                  min={5}
                  max={15}
                  step={1}
                  value={maxPlayers}
                  onValueChange={setMaxPlayers}
                  className="py-2"
                />
                <p className="text-xs text-muted-foreground">اللعبة تدعم من 5 إلى 15 لاعب</p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="space-y-0.5">
                  <Label htmlFor="isPrivate" className="text-red-100">غرفة خاصة</Label>
                  <p className="text-xs text-muted-foreground">لن تظهر في قائمة الغرف العامة</p>
                </div>
                <Switch 
                  id="isPrivate" 
                  checked={isPrivate}
                  onCheckedChange={setIsPrivate}
                />
              </div>

            </form>
          </CardContent>
          <CardFooter>
            <Button 
              type="submit" 
              form="create-room-form" 
              disabled={createRoom.isPending}
              className="w-full bg-red-700 hover:bg-red-800 text-white border-none h-12 text-lg font-bold"
            >
              {createRoom.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
              إنشاء وبدء
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}
