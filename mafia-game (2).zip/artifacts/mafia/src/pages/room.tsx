import { useEffect, useRef, useState } from "react";
import { useRoute } from "wouter";
import { useGetRoom, getGetRoomQueryKey } from "@workspace/api-client-react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { useGameSocket, type GamePlayer } from "@/hooks/use-game-socket";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { LuxeCard } from "@/components/luxe-card";
import { Skull, Send, Users, Clock, Crown, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const ROLE_NAMES_AR = {
  mafia: "المافيا",
  doctor: "الطبيب",
  detective: "المحقق",
  citizen: "المواطن"
};

export default function Room() {
  const [, params] = useRoute("/room/:code");
  const code = params?.code || "";
  const { toast } = useToast();

  const [storedName, setStoredName] = useLocalStorage<string>("mafia-player-name", "");
  const playerName = (() => {
    if (storedName) return storedName;
    if (typeof window === "undefined") return "";
    const fromUrl = new URLSearchParams(window.location.search).get("name");
    if (fromUrl) {
      setStoredName(fromUrl);
      return fromUrl;
    }
    return "";
  })();
  
  const { data: initialRoom, isLoading, isError } = useGetRoom(code, {
    query: {
      enabled: !!code && !!playerName,
      queryKey: getGetRoomQueryKey(code)
    }
  });

  const { state: wsState, send, connected, error: wsError } = useGameSocket(code, playerName);
  
  const [chatInput, setChatInput] = useState("");
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (wsError) {
      toast({
        title: "خطأ في الاتصال",
        description: wsError,
        variant: "destructive"
      });
    }
  }, [wsError, toast]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [wsState?.chat]);

  if (!playerName) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center p-8 bg-black/40 rounded-lg border border-red-900/30">
          <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">الاسم مفقود</h2>
          <p className="text-muted-foreground mb-4">يجب أن تحدد اسمك أولاً للدخول للغرفة.</p>
          <Button onClick={() => window.location.href = `/join?code=${code}`}>
            العودة لصفحة الانضمام
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading && !wsState) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center text-red-500 space-y-4">
        <div className="w-16 h-16 border-4 border-red-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xl font-bold animate-pulse">جاري دخول الغرفة...</p>
      </div>
    );
  }

  if (isError && !wsState) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-red-500 mb-4">الغرفة غير موجودة</h2>
        <Button onClick={() => window.location.href = "/"}>العودة للرئيسية</Button>
      </div>
    );
  }

  // Use WS state if available, otherwise fallback to initial REST state
  const currentPhase = wsState?.phase || initialRoom?.phase || 'lobby';
  const gameName = wsState?.name || initialRoom?.name || "ليلة المافيا";
  const players: GamePlayer[] = wsState?.players
    ?? (initialRoom?.players?.map((p) => ({
      id: p.id,
      name: p.name,
      isHost: p.isHost,
      isAlive: p.isAlive,
    })) ?? []);
  const isHost = wsState?.you?.isHost || players.find(p => p.name === playerName)?.isHost;
  const myRole = wsState?.you?.role;
  const isAlive = wsState?.you?.isAlive ?? true;
  
  const handleChatSubmit = (e: React.FormEvent, channel: 'public' | 'mafia' = 'public') => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    send({ type: "chat", text: chatInput, channel });
    setChatInput("");
  };

  const renderPlayerList = () => {
    return (
      <div className="flex flex-col h-full bg-black/60 border-l border-red-900/30 p-4 rounded-xl">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Users className="w-5 h-5" />
          اللاعبون ({players.length})
        </h3>
        <ScrollArea className="flex-1 -mx-4 px-4">
          <div className="space-y-2">
            <AnimatePresence>
              {players.map(p => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-colors
                    ${p.id === wsState?.you?.id ? 'bg-red-950/30 border-red-800/50' : 'bg-black/40 border-white/5'}
                    ${!p.isAlive ? 'opacity-50 grayscale' : ''}
                  `}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10 border border-white/10">
                      <AvatarFallback className={!p.isAlive ? 'bg-zinc-800' : 'bg-zinc-800 text-white'}>
                        {p.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                      <span className={`font-bold ${!p.isAlive ? 'line-through text-muted-foreground' : ''}`}>
                        {p.name} {p.id === wsState?.you?.id && '(أنت)'}
                      </span>
                      {p.isHost && <span className="text-xs text-yellow-500">المضيف</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {p.role && (
                      <Badge variant="outline" className="bg-black/50 border-amber-500/30 text-amber-200">
                        {ROLE_NAMES_AR[p.role]}
                      </Badge>
                    )}
                    {!p.isAlive && <Skull className="w-4 h-4 text-red-500" />}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </ScrollArea>
      </div>
    );
  };

  const renderChat = () => {
    const messages = wsState?.chat || [];
    return (
      <div className="flex flex-col h-full bg-black/60 border-r border-red-900/30 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-white/10 bg-black/40">
          <h3 className="text-lg font-bold">الدردشة</h3>
        </div>
        <ScrollArea className="flex-1 p-4" ref={chatScrollRef}>
          <div className="space-y-4">
            <AnimatePresence initial={false}>
              {messages.map((msg, i) => (
                <motion.div
                  key={msg.id || i}
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className={`flex flex-col ${msg.from === playerName ? 'items-end' : 'items-start'}`}
                >
                  <span className="text-xs text-muted-foreground mb-1 px-1">
                    {msg.channel === 'system' ? 'النظام' : msg.from}
                  </span>
                  <div className={`px-4 py-2 rounded-2xl max-w-[85%] break-words
                    ${msg.channel === 'system' ? 'bg-yellow-950/50 text-yellow-200 border border-yellow-900/30 font-bold w-full text-center' : 
                      msg.channel === 'mafia' ? 'bg-red-950 text-red-100 border border-red-900/50' :
                      msg.from === playerName ? 'bg-zinc-800 text-white rounded-br-none' : 'bg-zinc-900 text-zinc-200 rounded-bl-none'}
                  `}>
                    {msg.text}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </ScrollArea>
        <div className="p-4 border-t border-white/10 bg-black/40">
          {currentPhase !== 'ended' && isAlive ? (
            <form onSubmit={(e) => handleChatSubmit(e, 'public')} className="flex gap-2">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="اكتب رسالتك..."
                className="bg-black/50 border-white/10"
                disabled={currentPhase === 'night' && myRole !== 'mafia'}
              />
              <Button type="submit" size="icon" disabled={!chatInput.trim() || (currentPhase === 'night' && myRole !== 'mafia')}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
          ) : (
            <div className="text-center text-muted-foreground py-2 text-sm">
              {currentPhase === 'ended' ? 'انتهت اللعبة' : 'أنت ميت ولا يمكنك التحدث'}
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderCenterArea = () => {
    if (currentPhase === 'lobby') {
      return (
        <div className="flex flex-col items-center justify-center h-full space-y-8 p-8 text-center">
          <div className="space-y-3">
            <h1 className="text-4xl md:text-6xl font-black luxe-title drop-shadow-lg">
              {wsState?.name || initialRoom?.name}
            </h1>
            <div className="luxe-divider w-64 mx-auto" />
            <p className="text-xl text-muted-foreground flex items-center justify-center gap-2">
              كود الغرفة: <span className="font-mono bg-white/10 px-3 py-1 rounded text-amber-200 tracking-widest border border-amber-500/30">{code}</span>
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 max-w-3xl">
            {players.map((p) => (
              <LuxeCard
                key={p.id}
                name={p.name}
                gameName={gameName}
                isHost={p.isHost}
                size="sm"
                faceDown
              />
            ))}
            {Array.from({ length: Math.max(0, ((wsState?.maxPlayers || initialRoom?.maxPlayers) ?? 8) - players.length) }).map((_, i) => (
              <div
                key={`empty-${i}`}
                className="w-24 aspect-[5/7] rounded-[14px] border border-dashed border-amber-500/20 bg-black/20 grid place-items-center text-amber-500/40 text-xs"
              >
                مقعد شاغر
              </div>
            ))}
          </div>

          <div className="bg-black/40 p-6 rounded-xl border border-amber-500/20 max-w-md w-full">
            <div className="flex justify-between items-center mb-4 text-sm">
              <span className="text-amber-200">{players.length} انضموا</span>
              <span className="text-muted-foreground">الحد الأقصى {wsState?.maxPlayers || initialRoom?.maxPlayers}</span>
            </div>

            {isHost ? (
              <Button
                size="lg"
                className="w-full bg-gradient-to-b from-amber-500 to-amber-700 text-black font-black hover:from-amber-400 hover:to-amber-600 text-lg h-14 border border-amber-300/50 shadow-lg"
                disabled={players.length < 5}
                onClick={() => send({ type: 'start' })}
              >
                {players.length < 5 ? 'نحتاج 5 لاعبين على الأقل لبدء اللعبة' : 'ابدأ اللعبة'}
              </Button>
            ) : (
              <div className="text-center p-4 bg-amber-950/20 border border-amber-500/20 rounded text-amber-400 font-bold">
                في انتظار المضيف لبدء اللعبة
              </div>
            )}
          </div>
        </div>
      );
    }

    if (currentPhase === 'ended') {
      const winner = wsState?.winner;
      const isWinner = 
        (winner === 'mafia' && myRole === 'mafia') || 
        (winner === 'town' && myRole !== 'mafia');

      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-6 p-8 text-center overflow-y-auto"
        >
          <Crown className={`w-20 h-20 ${winner === 'mafia' ? 'text-red-500' : 'text-amber-400'}`} />
          <h1 className="text-5xl font-black luxe-title">
            فاز {winner === 'mafia' ? 'المافيا!' : 'المواطنون!'}
          </h1>
          <h2 className={`text-2xl font-bold ${isWinner ? 'text-amber-300' : 'text-muted-foreground'}`}>
            {isWinner ? 'لقد انتصرت!' : 'حظ أوفر المرة القادمة'}
          </h2>
          <div className="luxe-divider w-72" />

          <h3 className="text-xl font-bold text-amber-200">كشف الأدوار</h3>
          <div className="flex flex-wrap justify-center gap-4 max-w-4xl">
            {players.map((p, i) => (
              <div key={p.id} style={{ animationDelay: `${i * 80}ms` }}>
                <LuxeCard
                  name={p.name}
                  role={p.role}
                  isHost={p.isHost}
                  isAlive={p.isAlive}
                  size="sm"
                  flipIn
                />
              </div>
            ))}
          </div>
        </motion.div>
      );
    }

    return (
      <div className="flex flex-col items-center h-full p-6 space-y-6">
        <motion.div 
          key={currentPhase}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <Badge variant="outline" className={`px-4 py-1 text-lg border-2 ${currentPhase === 'night' ? 'border-indigo-500 text-indigo-400 bg-indigo-950/30' : 'border-amber-500 text-amber-500 bg-amber-950/30'}`}>
            {currentPhase === 'night' ? 'الليل' : 'النهار'}
          </Badge>
          <div className="flex items-center justify-center gap-2 text-3xl font-black">
            <Clock className="w-8 h-8" />
            {wsState?.timeRemaining || 0} ثانية
          </div>
        </motion.div>

        {myRole && (
          <Card className="w-full max-w-md bg-black/50 border-amber-500/20 overflow-hidden">
            <CardContent className="p-4 flex items-center gap-4">
              <LuxeCard role={myRole} name="دورك السري" size="sm" flipIn />
              <div className="flex-1 text-right">
                <p className="text-amber-200/70 text-xs mb-1">هويتك</p>
                <div className="text-2xl font-black luxe-title">{ROLE_NAMES_AR[myRole]}</div>
                <Badge variant={isAlive ? 'default' : 'destructive'} className="mt-2 text-sm px-3 py-1">
                  {isAlive ? 'على قيد الحياة' : 'ميت'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex-1 w-full max-w-3xl bg-black/40 rounded-xl border border-amber-500/15 p-6 flex flex-col">
          <h3 className="text-xl font-bold mb-6 text-center text-amber-100/90">
            {currentPhase === 'night'
              ? 'المدينة نائمة...'
              : 'ناقش وصوّت لمن تظن أنه المافيا!'}
          </h3>

          {isAlive && currentPhase === 'day' && (
            <div className="flex flex-wrap justify-center gap-4">
              {players.filter(p => p.isAlive && p.id !== wsState?.you?.id).map(p => {
                const myVote = wsState?.votes?.find(v => v.voterId === wsState?.you?.id);
                const selected = myVote?.targetId === p.id;
                return (
                  <div key={p.id} className="flex flex-col items-center gap-2">
                    <LuxeCard
                      name={p.name}
                      gameName={gameName}
                      isHost={p.isHost}
                      faceDown
                      size="sm"
                      isSelected={selected}
                      onClick={() => send({ type: 'vote', targetId: p.id })}
                    />
                    <span className="text-xs text-amber-200/70">{selected ? '✓ صوتك' : 'صوّت'}</span>
                  </div>
                );
              })}
            </div>
          )}

          {isAlive && currentPhase === 'night' && myRole && myRole !== 'citizen' && (
            <div className="space-y-4">
              <p className="text-center text-amber-200/70 mb-4">
                {myRole === 'mafia' ? 'اختر ضحيتك لهذه الليلة' :
                 myRole === 'doctor' ? 'اختر من تريد حمايته الليلة' :
                 'اختر شخصاً للتحقق من هويته'}
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                {players.filter(p => p.isAlive).map(p => (
                  <LuxeCard
                    key={p.id}
                    name={p.name}
                    gameName={gameName}
                    isHost={p.isHost}
                    faceDown
                    size="sm"
                    onClick={() => send({ type: 'action', targetId: p.id })}
                  />
                ))}
              </div>
            </div>
          )}

          {!isAlive && (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-lg">
              أنت مراقب الآن. يمكنك رؤية ما يحدث لكن لا يمكنك المشاركة.
            </div>
          )}
        </div>
        
        {isAlive && (
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => send({ type: 'ready' })}
            className="w-full max-w-md font-bold text-lg"
          >
            أنا مستعد
          </Button>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen w-full relative transition-colors duration-1000 ${
      currentPhase === 'night' ? 'phase-night' : currentPhase === 'day' ? 'phase-day' : 'bg-background'
    }`}>
      <div className="noise-overlay" />
      
      {/* Top connection status */}
      {!connected && (
        <div className="absolute top-0 inset-x-0 bg-red-600 text-white text-center py-1 text-sm z-50">
          جاري الاتصال بالخادم...
        </div>
      )}

      <div className="container mx-auto h-screen p-4 flex flex-col lg:flex-row gap-4 relative z-10 pt-8 lg:pt-4">
        
        {/* Left: Players */}
        <div className="hidden lg:block w-72">
          {renderPlayerList()}
        </div>

        {/* Center: Main Game Area */}
        <div className="flex-1 min-h-[50vh]">
          {renderCenterArea()}
        </div>

        {/* Right: Chat */}
        <div className="hidden lg:block w-80">
          {renderChat()}
        </div>

        {/* Mobile: Stacked bottom sections */}
        <div className="lg:hidden flex flex-col gap-4 mt-auto">
          <div className="h-[30vh]">
            {renderChat()}
          </div>
        </div>

      </div>
    </div>
  );
}
