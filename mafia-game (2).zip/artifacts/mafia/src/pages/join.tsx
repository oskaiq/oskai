import { useState, useEffect } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useAuth } from "@workspace/replit-auth-web";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function JoinRoom() {
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const codeParam = searchParams.get("code") || "";

  const { toast } = useToast();
  const [playerName, setPlayerName] = useLocalStorage<string>("mafia-player-name", "");
  const [roomCode, setRoomCode] = useState(codeParam);
  const { user } = useAuth();

  useEffect(() => {
    if (user && !playerName) {
      const name =
        user.firstName ||
        (user.email ? user.email.split("@")[0] : "");
      if (name) setPlayerName(name);
    }
  }, [user, playerName, setPlayerName]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode || !playerName) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال كود الغرفة واسم اللاعب",
        variant: "destructive"
      });
      return;
    }

    setLocation(`/room/${roomCode.toUpperCase()}`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4 relative overflow-hidden">
      <div className="noise-overlay" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        <Link href="/" className="inline-flex items-center text-muted-foreground hover:text-white mb-6 transition-colors">
          <ArrowRight className="w-4 h-4 ml-2" /> عودة للرئيسية
        </Link>
        
        <Card className="bg-black/60 border-red-900/30 backdrop-blur-md shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-red-500">الانضمام لغرفة</CardTitle>
            <CardDescription className="text-muted-foreground">
              أدخل كود الغرفة واسمك للانضمام للعب
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form id="join-room-form" onSubmit={handleSubmit} className="space-y-6">
              
              <div className="space-y-2">
                <Label htmlFor="roomCode" className="text-red-100">كود الغرفة</Label>
                <Input 
                  id="roomCode" 
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value)}
                  placeholder="مثال: ABCD" 
                  className="bg-black/40 border-red-900/50 focus:border-red-500 uppercase font-mono tracking-widest text-lg"
                  maxLength={6}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="playerName" className="text-red-100">اسمك</Label>
                <Input 
                  id="playerName" 
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="كيف تريد أن يناديك اللاعبون؟" 
                  className="bg-black/40 border-red-900/50 focus:border-red-500"
                  required
                />
              </div>

            </form>
          </CardContent>
          <CardFooter>
            <Button 
              type="submit" 
              form="join-room-form" 
              className="w-full bg-red-700 hover:bg-red-800 text-white border-none h-12 text-lg font-bold"
            >
              انضمام
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}
