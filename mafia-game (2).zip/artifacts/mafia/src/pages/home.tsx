import { Link } from "wouter";
import { 
  useListRooms, 
  getListRoomsQueryKey,
  useGetStatsOverview,
  useGetLeaderboard,
  useGetRecentGames,
  useGetRoleWinrates
} from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Swords, Trophy, Activity, ArrowLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AuthBadge } from "@/components/auth-badge";

export default function Home() {
  const { data: rooms, isLoading: isLoadingRooms } = useListRooms({
    query: { refetchInterval: 5000, queryKey: getListRoomsQueryKey() }
  });
  
  const { data: stats } = useGetStatsOverview();
  const { data: leaderboard } = useGetLeaderboard();
  const { data: recentGames } = useGetRecentGames();
  const { data: roleWinrates } = useGetRoleWinrates();

  return (
    <div className="min-h-screen bg-background text-foreground pb-20 relative overflow-hidden">
      <div className="noise-overlay" />

      {/* Top bar with auth */}
      <div className="absolute top-0 left-0 right-0 z-20 flex justify-end p-4">
        <AuthBadge />
      </div>

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 flex flex-col items-center justify-center text-center px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl mx-auto"
        >
          <h1 className="text-6xl md:text-8xl font-black text-red-600 mb-6 drop-shadow-md">
            ليلة المافيا
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            المدينة تنام، وتستيقظ المافيا. هل يمكنك كشف الحقيقة قبل فوات الأوان؟ العب لعبة الاستنتاج الاجتماعي الأكثر إثارة مع أصدقائك.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/create">
              <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-8 bg-red-700 hover:bg-red-800 text-white border-none">
                أنشئ غرفة
              </Button>
            </Link>
            <Link href="/join">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg h-14 px-8 bg-black/40 border-red-900/30 hover:bg-red-950/20 text-red-50 hover:text-white">
                انضم بكود
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Stats Strip */}
      <section className="border-y border-red-900/20 bg-black/40 backdrop-blur-sm py-6 my-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="flex items-center justify-center text-red-500 mb-2">
                <Activity className="w-6 h-6" />
              </div>
              <div className="text-3xl font-bold">{stats?.activeRooms ?? "-"}</div>
              <div className="text-sm text-muted-foreground">غرف نشطة</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-center text-red-500 mb-2">
                <Users className="w-6 h-6" />
              </div>
              <div className="text-3xl font-bold">{stats?.playersOnline ?? "-"}</div>
              <div className="text-sm text-muted-foreground">لاعبين متصلين</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-center text-red-500 mb-2">
                <Swords className="w-6 h-6" />
              </div>
              <div className="text-3xl font-bold">{stats?.gamesToday ?? "-"}</div>
              <div className="text-sm text-muted-foreground">مباريات اليوم</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-center text-red-500 mb-2">
                <Trophy className="w-6 h-6" />
              </div>
              <div className="text-3xl font-bold">{stats?.totalGames ?? "-"}</div>
              <div className="text-sm text-muted-foreground">إجمالي المباريات</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Grid */}
      <section className="container mx-auto px-4 mt-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Public Rooms */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="w-2 h-8 bg-red-600 rounded-sm"></span>
                الغرف العامة
              </h2>
            </div>

            {isLoadingRooms ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full bg-black/20" />)}
              </div>
            ) : rooms?.length === 0 ? (
              <div className="text-center py-12 bg-black/20 rounded-lg border border-red-900/20">
                <p className="text-muted-foreground">لا توجد غرف عامة متاحة حالياً.</p>
                <Link href="/create">
                  <Button variant="link" className="text-red-500 mt-2">كن أول من ينشئ غرفة</Button>
                </Link>
              </div>
            ) : (
              <div className="grid gap-4">
                {rooms?.map(room => (
                  <Card key={room.code} className="bg-black/40 border-red-900/30 hover:border-red-600/50 transition-colors">
                    <CardContent className="p-6 flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-xl mb-2">{room.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" /> المضيف: {room.hostName}
                          </span>
                          <span className="flex items-center gap-1">
                            <Activity className="w-4 h-4" /> {room.playerCount} / {room.maxPlayers}
                          </span>
                          <Badge variant={room.phase === 'lobby' ? 'outline' : 'secondary'} className="bg-transparent text-white border-white/20">
                            {room.phase === 'lobby' ? 'في الانتظار' : room.phase === 'day' ? 'النهار' : room.phase === 'night' ? 'الليل' : 'انتهت'}
                          </Badge>
                        </div>
                      </div>
                      <Link href={`/join?code=${room.code}`}>
                        <Button className="bg-white/10 hover:bg-red-600 text-white">
                          <ArrowLeft className="w-5 h-5 ml-2" /> انضمام
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Metagame Stats */}
          <div className="space-y-8">
            <Card className="bg-black/40 border-red-900/30">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-500" /> لوحة الشرف
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {leaderboard?.map((entry, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 rounded bg-black/20 border border-white/5">
                    <div className="flex items-center gap-3">
                      <span className={`font-bold w-6 text-center ${idx === 0 ? 'text-yellow-500' : idx === 1 ? 'text-gray-400' : idx === 2 ? 'text-amber-700' : 'text-muted-foreground'}`}>
                        #{idx + 1}
                      </span>
                      <span className="font-medium">{entry.playerName}</span>
                    </div>
                    <div className="text-sm font-bold text-red-400">{entry.wins} فوز</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-red-900/30">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="w-5 h-5 text-red-500" /> نسب الفوز للأدوار
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {roleWinrates?.map((rw, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{rw.role}</span>
                      <span className="font-bold">{rw.winRate.toFixed(1)}%</span>
                    </div>
                    <div className="h-2 w-full bg-black/40 rounded overflow-hidden">
                      <div 
                        className={`h-full ${rw.role === 'مافيا' ? 'bg-red-600' : 'bg-blue-600'}`} 
                        style={{ width: `${rw.winRate}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-red-900/30">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Swords className="w-5 h-5 text-zinc-400" /> مباريات حديثة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentGames?.map((game) => (
                  <div key={game.id} className="flex flex-col p-3 rounded bg-black/20 border border-white/5 text-sm">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold">{game.roomName}</span>
                      <span className={`font-bold ${game.winner === 'mafia' ? 'text-red-500' : 'text-blue-400'}`}>
                        فاز {game.winner === 'mafia' ? 'المافيا' : 'المواطنون'}
                      </span>
                    </div>
                    <div className="flex justify-between text-muted-foreground text-xs">
                      <span>{game.playerCount} لاعبين</span>
                      <span>{Math.floor(game.durationSeconds / 60)} دقيقة</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

        </div>
      </section>
    </div>
  );
}
