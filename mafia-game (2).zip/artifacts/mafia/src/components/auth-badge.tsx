import { useAuth } from "@workspace/replit-auth-web";
import { Button } from "@/components/ui/button";
import { LogIn, LogOut, User } from "lucide-react";

export function AuthBadge() {
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();

  if (isLoading) {
    return (
      <div className="h-10 w-32 rounded-md bg-black/40 border border-yellow-900/20 animate-pulse" />
    );
  }

  if (!isAuthenticated) {
    return (
      <Button
        onClick={login}
        size="lg"
        className="bg-gradient-to-b from-yellow-500 to-yellow-700 hover:from-yellow-400 hover:to-yellow-600 text-black font-bold border border-yellow-300/50 shadow-lg shadow-yellow-900/30"
        data-testid="button-login"
      >
        <LogIn className="w-4 h-4 ml-2" />
        تسجيل الدخول
      </Button>
    );
  }

  const displayName =
    user?.firstName ||
    (user?.email ? user.email.split("@")[0] : "اللاعب");

  return (
    <div className="flex items-center gap-3">
      <div
        className="flex items-center gap-2 px-3 py-2 rounded-md bg-black/40 border border-yellow-900/30"
        data-testid="auth-user"
      >
        {user?.profileImageUrl ? (
          <img
            src={user.profileImageUrl}
            alt=""
            className="w-7 h-7 rounded-full border border-yellow-700/40"
          />
        ) : (
          <div className="w-7 h-7 rounded-full bg-yellow-900/40 border border-yellow-700/40 flex items-center justify-center">
            <User className="w-4 h-4 text-yellow-400" />
          </div>
        )}
        <span className="text-sm font-semibold text-yellow-100">
          أهلاً، {displayName}
        </span>
      </div>
      <Button
        onClick={logout}
        size="sm"
        variant="outline"
        className="bg-black/40 border-red-900/30 hover:bg-red-950/20 text-red-200"
        data-testid="button-logout"
      >
        <LogOut className="w-4 h-4 ml-2" />
        خروج
      </Button>
    </div>
  );
}
