import type { ReactNode } from "react";
import { Skull, HeartPulse, Search, User, Crown } from "lucide-react";
import type { PlayerRole } from "@/hooks/use-game-socket";

interface LuxeCardProps {
  name?: string;
  gameName?: string;
  role?: PlayerRole;
  isHost?: boolean;
  isAlive?: boolean;
  isSelected?: boolean;
  faceDown?: boolean;
  showRole?: boolean;
  onClick?: () => void;
  className?: string;
  size?: "sm" | "md" | "lg";
  flipIn?: boolean;
}

const ROLE_LABEL: Record<PlayerRole, string> = {
  mafia: "المافيا",
  doctor: "الطبيب",
  detective: "المحقق",
  citizen: "مواطن",
};

const ROLE_INITIAL: Record<PlayerRole, string> = {
  mafia: "م",
  doctor: "ط",
  detective: "ح",
  citizen: "م",
};

function RoleCrest({ role }: { role: PlayerRole }) {
  const common = "w-1/2 h-1/2";
  switch (role) {
    case "mafia":
      return <Skull className={`${common} text-red-400`} strokeWidth={1.4} />;
    case "doctor":
      return <HeartPulse className={`${common} text-emerald-300`} strokeWidth={1.4} />;
    case "detective":
      return <Search className={`${common} text-sky-300`} strokeWidth={1.4} />;
    case "citizen":
      return <User className={`${common} text-amber-200`} strokeWidth={1.4} />;
  }
}

const SIZES: Record<NonNullable<LuxeCardProps["size"]>, string> = {
  sm: "w-24",
  md: "w-36",
  lg: "w-52",
};

export function LuxeCard(props: LuxeCardProps): ReactNode {
  const {
    name,
    gameName,
    role,
    isHost,
    isAlive = true,
    isSelected,
    faceDown,
    showRole = true,
    onClick,
    className = "",
    size = "md",
    flipIn,
  } = props;

  const variantClass = faceDown
    ? "luxe-card-back"
    : role
    ? `luxe-card-${role}`
    : "luxe-card-citizen";

  const cls = [
    "luxe-card",
    variantClass,
    SIZES[size],
    !isAlive && "luxe-card-dead",
    isSelected && "is-selected",
    onClick && "is-selectable",
    flipIn && "flip-in",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  if (faceDown) {
    return (
      <div className={cls} onClick={onClick} role={onClick ? "button" : undefined}>
        {isHost && <div className="badge-host">المضيف</div>}
        <div className="center">
          <div className="crest">
            <span className="text-3xl font-black" style={{ color: "var(--gold-1)" }}>
              م
            </span>
          </div>
          {gameName && (
            <div className="role-name" style={{ fontSize: 10, opacity: 0.9, lineHeight: 1.2, textAlign: "center", maxWidth: "90%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {gameName}
            </div>
          )}
          {name && (
            <div className="name" style={{ fontSize: size === "sm" ? 10 : 12 }}>
              {name}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cls} onClick={onClick} role={onClick ? "button" : undefined}>
      {isHost && <div className="badge-host">المضيف</div>}
      {role && showRole && (
        <>
          <div className="corner corner-tr">
            <span>{ROLE_INITIAL[role]}</span>
            <span className="pip">
              {role === "mafia" && "♠"}
              {role === "doctor" && "♥"}
              {role === "detective" && "♦"}
              {role === "citizen" && "♣"}
            </span>
          </div>
          <div className="corner corner-bl">
            <span>{ROLE_INITIAL[role]}</span>
            <span className="pip">
              {role === "mafia" && "♠"}
              {role === "doctor" && "♥"}
              {role === "detective" && "♦"}
              {role === "citizen" && "♣"}
            </span>
          </div>
        </>
      )}

      <div className="center">
        <div className="crest">
          {role && showRole ? (
            <RoleCrest role={role} />
          ) : (
            <Crown className="w-1/2 h-1/2" style={{ color: "var(--gold-1)" }} strokeWidth={1.4} />
          )}
        </div>
        {gameName && (
          <div className="role-name" style={{ fontSize: 10, opacity: 0.85, lineHeight: 1.2, textAlign: "center", maxWidth: "90%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {gameName}
          </div>
        )}
        {role && showRole && <div className="role-name">{ROLE_LABEL[role]}</div>}
        {name && <div className="name">{name}</div>}
      </div>

      {!isAlive && (
        <div className="skull-stamp">
          <div className="stamp">منتهي</div>
        </div>
      )}
    </div>
  );
}
