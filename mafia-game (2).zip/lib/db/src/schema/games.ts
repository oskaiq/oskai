import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";

export const gamesTable = pgTable("games", {
  id: serial("id").primaryKey(),
  roomName: text("room_name").notNull(),
  winner: text("winner").notNull(),
  playerCount: integer("player_count").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  endedAt: timestamp("ended_at", { withTimezone: true }).notNull().defaultNow(),
});

export const gamePlayersTable = pgTable("game_players", {
  id: serial("id").primaryKey(),
  gameId: integer("game_id").notNull().references(() => gamesTable.id, { onDelete: "cascade" }),
  playerName: text("player_name").notNull(),
  role: text("role").notNull(),
  isWinner: boolean("is_winner").notNull(),
});

export type Game = typeof gamesTable.$inferSelect;
export type GamePlayer = typeof gamePlayersTable.$inferSelect;
